from Queue import Queue

def split(q):
    qu = Queue() 
    qu1 = Queue()
    i = 0 
    lst = []
    while not q.isempty():
        s = q.dequeue()
        lst.append(s)
         
    
   
    while i < len(lst)/2:
        qu.enqueue(lst[i])
        i += 1
    while i < len(lst):
        qu1.enqueue(lst[i])
        i += 1
    return (qu,qu1)
    
