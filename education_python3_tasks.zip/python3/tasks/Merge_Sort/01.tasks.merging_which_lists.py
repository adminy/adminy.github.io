#
#   Return [] to get your two lists.
#
#   Then return a list containing the solution
#lst1 = [15, 24, 30, 31, 35]
#lst2 = [8, 11, 19, 21, 26]

def solution():
    return ['L2','L2','L1','L2','L2','L1','L2','L1','L1','L1']
