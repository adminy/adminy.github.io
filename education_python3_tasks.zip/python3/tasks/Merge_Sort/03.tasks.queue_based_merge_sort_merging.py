from Queue import Queue

def merge(q1, q2, q)
    q = Queue()
    lst = []
    while not q1.isempty():
        k = q1.dequeue()
        lst.append(k)
        
    while not q2.isempty():
        k = q2.dequeue()
        lst.append(k)
        
    lst = sorted(lst)
    print(lst)
    i = 0
    while i < len(lst):
        q.enqueue(lst[i])
        i += 1
    
