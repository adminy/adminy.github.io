def check_brackets(line):
    class Stack:
        def __init__(self):
            self.items = []
        def isEmpty(self):
            return self.items == []
        def push(self, item):
            self.items.append(item)
        def pop(self):
            return self.items.pop()
    if line:
        b = [ ('(',')'), ('[',']'), ('{','}')]
        j,x = 1,0
        st = Stack()
    for i in line:
        for p in b:
            if i == p[x]:
                st.push(i)
            elif i == p[j] and (st.isEmpty() or st.pop() != p[x]):
                return False
    if st.isEmpty():
        return True
    return False
