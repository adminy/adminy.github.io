#  Stack ADT has three methods: is_empty, push and pop
from Stack import Stack
from sys import stdin
def reverse_input(stack):
    stack = Stack()
    for line in stdin.readlines():
        if line.strip():stack.push(line.strip())
    while not stack.is_empty():
        print(stack.pop())
