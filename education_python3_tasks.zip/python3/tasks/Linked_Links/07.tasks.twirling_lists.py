class Node:
    def __init__(self, item, next):self.item,self.next = item,next
class LinkedList:
    def __init__(self):self.head = None
    def is_empty(self):return self.head == None
    def add(self, item):self.head = Node(item, self.head) #head = Node("value3",Node("value2",Node("value1",None)))
    def remove(self):
        if self.is_empty():return None
        else:
            item = self.head.item
            self.head = self.head.next    # remove the item by moving the head pointer
            return item
    def __str__(self):
        ptr,tmp_str = self.head,""
        while ptr != None:
            tmp_str += " " + ptr.item
            ptr = ptr.next
        return tmp_str
#our code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
    def rotate(self):
        header = self.head
        self.head = self.head.next
        ptr = self.head
        while ptr.next:
            ptr = ptr.next
        ptr.next = Node(header.item, None)
