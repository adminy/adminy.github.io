class Node:
    def __init__(self, item, next):self.item,self.next = item,next
class LinkedList:
    def __init__(self):self.head = None
    def is_empty(self):return self.head == None
    def add(self, item):self.head = Node(item, self.head)
    def remove(self):
        if self.is_empty():return None
        else:
            item = self.head.item
            self.head = self.head.next    # remove the item by moving the head pointer
            return item
#our code ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            
    def before(self,item):
      ptr = self.head
      while ptr != None and ptr.next != None:
          if ptr.next.item == item:return ptr.item
          ptr = ptr.next
      return None
