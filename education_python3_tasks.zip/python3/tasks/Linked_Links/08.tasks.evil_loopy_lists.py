def detect_loop(self):
    ptr = self.head
    while ptr:
       ptr = ptr.next
       if self.head == ptr:return True
    return False
