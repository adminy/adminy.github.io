def even_count(self):
    ptr,count = self.head,0
    while ptr != None:
        if not ptr.item % 2:count += 1
        ptr = ptr.next
    return count
