#printing in python 

print("Hello From Me!")

#command line argument

from sys import argv; print(argv[1])

#command line arguments *

from sys import argv;
for arg in argv[1:]:print(arg)

#collonated command line arguments

from sys import argv;print("".join([':' + arg for arg in argv[1:]]) + ':')

#Write a python program which determines if a string has an even or odd number of characters.
#Should the string have an even number of characters, it prints the second half of the string.
#Otherwise it prints only the first and last letters of the string.
#The string will be passed to your program on the command line.

from sys import argv;
s = argv[1]
if len(s)%2:
	print(s[0]+s[-1])
else:
	print(s[int(len(s)/2):])


#Write a python program which reads a string on the command line and prints all consecutive pairs of characters of the string.

from sys import argv;
for i in range(len(argv[1])-1):print(argv[1][i:i+2])

#Write a python function which takes two parameters, a list of integers and a number, k, and which prints every pair of numbers in the list which add up to k.
#You should use an O(n2) algorithm in your solution.
#Your function should be called sum_to_k(), should take two parameters.

def sum_to_k(lst, k):
	lst = [passed for passed in lst if passed <= k]  
	
	for i in range(len(lst)):
		for j in range(i,len(lst)):
			if lst[i] + lst[j] == k:
				print(lst[i], lst[j]) 


#Define a function called calc_average() in a python program.
#The function should have one parameter which is a list of integers and should return a single value which is the average of the integers in the list.
#Your function will be tested using the following code:
#import sys
#from average import calc_average # student's function
###   Read a list from stdin
#line = sys.stdin.readline()
#tokens = line.split()
#list = []
#for token in tokens:
#    list.append(int(token))
###   Call the function + print result
#print(calc_average(list))

def calc_average(numbers):return sum(numbers)/len(numbers)

#Define a function called above_average(). The function should have one parameter which is a list of integers and should return a new list which is all the elements of the original list which are larger than the average.
#Your function will be tested using the following program:

#import sys
#from average import above_average
###   Read a list from stdin
#line = sys.stdin.readline()
#tokens = line.split()
#list = []
#for tok in tokens:
#    list.append(int(tok))
###   Call the function + print result
#print(above_average(list))

#Define a function called get_plural(). The function should have one parameter which is a word (a noun) and the function should return the plural of the word based on the following rules:
#Add es if the noun ends in ch, sh, x, s or z.
#If a noun ends in a consonant + y drop the y and add ies.
#If a noun ends in f (or fe) drop the f (or fe) and add ves.
#If a noun ends in o add es.
#Otherwise add s.

#Your function will be tested using a program similar to the following:
#import sys
#from word import get_plural
#def check(word, plural):
#    return 1 # if the plural is correct or 0 otherwise.
#words = ["beach", "fish", "fox", "bus", "fez", "potato", "fairy", "lady", "boy", "elf", "knife", "fog", "tissue"]
#num_correct = 0
#for word in words:
#    num_correct += check(word, get_plural(word))
#print("All Good" if num_correct == len(words) else str(len(words) - num_correct) + " incorrect.")

def get_plural(word):
    if word[-2:] in ['ch', 'sh'] or word[-1:] in ['x', 's', 'z']:
        return word+'es'
    elif len(word) > 1 and word[-2:] in ['fe'] or len(word) > 1 and word[-1:] in ['f']:
        if word[-1] == "e":
            return word[:-2] + "ves"
        return word[:-1] + "ves"
          
    vowels = "aeiou"
    if len(word) > 1 and word[-2] not in vowels and word[-1] == "y":
        return word[:-1] + "ies"
    
    if word[-1] == "o":
        return word + "es"
        
    else:
        return word + "s"

#Write a recursive function called rprint to print a range of integers from a to b.
def rprint(a, b):
	#base case
	if a == b:
		return
	#repeatitive function
	print(a)
	rprint(a+1,b)

#Write a recursive function called sumto() which will compute the sum of a range of integers from a to b.
def sumto(a, b):
	#base case
	if a == b-1:
		return a
	#repeatitive function
	else:
		return a + sumto(a+1,b)
   
#Write a recursive function called maximum() which will find the maximum value in a list of integers. You may assume that the list contains at least one element.
def maxi(a, b):
   if a >= b:
      return a
   else:
      return b

def maximum(lst):
    if len(lst) < 2:
        return lst[0]
    return maximum(lst[2:] + [maxi(lst[0],lst[1])])
    

#Write a recursive method called is_palindrome to determine whether a string is a palindrome or not. The method will have one parameter, the string to be tested and will return a boolean value indicating whether the string is a palindrome.
def is_palindrome(word):
    if len(word) < 2:
        return True
    if word[0] == word[-1]:
        return is_palindrome(word[1:-1])
    else:
        return False

#warmed up ? eto ... not really ... 
