def make_list1(lst, n_list):
    lst = sorted(lst)
    if len(lst) == 0:
        return n_list
    
    mid = len(lst)//2
  
    n_list.append(lst[mid])
    
    make_list1(lst[:mid],n_list) 
    make_list1(lst[mid+1:], n_list) 
    return n_list

    


def make_list(lst):
   return make_list1(lst, [])

