def recursive_height(ptr):
   if ptr == None:
       return 0
   else:
       return 1 + max(recursive_height(ptr.left),recursive_height(ptr.right))

def height(self):
   return recursive_height(self.root)

def rec_is_maximal(bst, ptr, cur_height, max_height):
    if (ptr.right == None and ptr.left != None) or (ptr.left == None and ptr.right != None):
        return False
    if ptr.right == None and ptr.left == None:
        if cur_height != max_height:
            return False
        return True
    right = rec_is_maximal(bst, ptr.right, cur_height + 1, max_height)
    left = rec_is_maximal(bst, ptr.left, cur_height + 1, max_height)
    return right and left
    
def is_maximal(bst):
    if bst.root == None:
        return False
    max_height = height(bst)
    cur_height = 1
    ptr = bst.root
    return rec_is_maximal(bst, ptr, cur_height, max_height)
