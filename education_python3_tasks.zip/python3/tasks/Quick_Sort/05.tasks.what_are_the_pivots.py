#
#   Return [] to get your list of numbers.
#
#   Then return a list containing solution(s)
#[15, 21, 19, 8, 24, 11]
def solution():
    return [11,19]
