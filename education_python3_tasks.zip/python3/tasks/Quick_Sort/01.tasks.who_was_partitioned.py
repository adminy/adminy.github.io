#
#   Return [] to get your list of numbers.
#
#   Then return a list containing solution(s)
#[8, 19, 26, 11, 21, 24, 15, 30, 31]
def solution():
    return [8, 30, 31]
