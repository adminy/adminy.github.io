#
#   Insertion Sort
#
#   First place the smallest element at the front of the list to act as a sentinel
#
def insertion_sort(lst):
    if len(lst) == 0:return (0,0)
    #Swapping Smallest element in first position
    min_index = 0
    for i in range(1, len(lst)):
        if lst[i] < lst[min_index]:
            min_index = i;
    lst[0], lst[min_index] = lst[min_index], lst[0]
#Start of our program
    moves = 1
    for todo in range(2, len(lst)):
        store = lst[todo]
        i = todo
        while store < lst[i-1]: # Don't need to check i > 0
            lst[i] = lst[i-1] # Make space for the item
            moves += 1
            i -= 1
        moves += 2
        lst[i] = store  # Found the place for this item, plonk it in
    return (moves,moves + 2)

