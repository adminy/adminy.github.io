#
#   Return an empty list to get your list of numbers.
#
#   Then return a list of lists corresponding to the passes of an insertion sort on the numbers.
#
def solution():
    return [ #[15, 21, 19, 24, 8, 11]
             [15, 21],
             [15, 19, 21],
             [15, 19, 21, 24],
             [8, 15, 19, 21, 24],
             [8, 11, 15, 19, 21, 24]
           ]
