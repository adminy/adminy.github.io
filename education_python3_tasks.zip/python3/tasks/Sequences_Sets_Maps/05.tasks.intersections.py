def set_intersection(s1,s2):return list(set(s1) & set(s2))
