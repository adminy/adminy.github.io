from sys import argv; f1,f2 = argv[1],argv[2];
f1_open = open(f1).read().split("\n")
f2_open = open(f2).read().split("\n")
people_storage = []
for names in f1_open:
    if names in f2_open:people_storage.append(names)
i = 0
s = [c for c in sorted(people_storage) if c]
while i < len(s):
    print(str(i+1)+". "+s[i])
    i += 1
        
