from sys import stdin
def make_map():
  students = {}
  for line in stdin:
      line = line.strip().split()
      if line:
          students[line[0]] = line[1]
  return students
