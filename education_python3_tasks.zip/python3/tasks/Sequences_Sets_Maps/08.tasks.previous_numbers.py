s = "Enter numbers (-1 to end): "
a = int(input())
exist = []
while a != -1:
    if a in exist:s += str(a) + " "
    else:exist.append(a)
    a = int(input())
print(s)
