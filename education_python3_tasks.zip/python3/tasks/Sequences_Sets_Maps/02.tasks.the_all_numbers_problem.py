from sys import stdin
def get_evenodd_list():
  olst,elst = [],[]
  s = int(input())
  while s != -1:
      if s % 2 != 0:olst.append(s)
      else:elst.append(s)
      s = int(input())
  return olst,elst
