def get_counts_dict(lst):
  d = {}
  for w in lst:
      if len(w) in d:d[len(w)] += 1
      else:d[len(w)] = 1
  return d
