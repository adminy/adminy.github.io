from sys import stdin;print("Enter a name and number, or a name and ? to query (!! to exit)")
d = {}
for cmds in stdin:
    if cmds.strip() == "!!" or len(cmds.strip()) < 1:break;
    cmd = cmds.strip().split()
    if cmd[0] not in d and cmd[1] == "?":print("Sorry, there is no", cmd[0])
    else:
        if cmd[1] != "?":d[cmd[0]] = cmd[1]
        else:print(cmd[0],"has number",d[cmd[0]])
print("Bye")
