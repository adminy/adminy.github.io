def set_stuff(a,b):return (a|b,a.issubset(b),a.issuperset(b))
