def unique_list(lst):return list(set(lst))
