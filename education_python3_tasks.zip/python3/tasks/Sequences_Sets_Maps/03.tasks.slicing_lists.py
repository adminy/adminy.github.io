def get_sliced_lists(lst):return lst[:-1],lst[1:-1],lst[1:-1],lst[::-1]
