from sys import stdin
def get_odd_list():
  lst = []
  s = int(input())
  while s != -1:
      if s % 2 != 0:lst.append(s)
      s = int(input())
  return lst
