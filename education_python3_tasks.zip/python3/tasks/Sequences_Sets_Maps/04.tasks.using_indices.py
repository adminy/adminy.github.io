def get_counts(lst):
    d = {0:0,1:0,2:0,3:0,4:0,5:0,6:0,7:0,8:0,9:0,10:0}
    for x in lst:d[len(x)] += 1
    return d
