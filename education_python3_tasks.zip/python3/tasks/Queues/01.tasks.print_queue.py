def print_queue(lst,front,back):
     while front != back:
         print(lst[front])
         front += 1
         if front == len(lst):
             front = 0
