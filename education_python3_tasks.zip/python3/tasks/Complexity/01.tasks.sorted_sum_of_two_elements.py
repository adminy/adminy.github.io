def bsearch(a,q):
  first = 0
  last = len(a)
  while first < last:
    center = (first+last)//2
    assert first <= center < last
    if a[center] < q:
      first = center + 1
      assert first == 0 or a[first-1] < q
    else:
      last = center
      assert q <= a[last]
  return first


def sum_to_k(lst, k):
  for x in lst:
    t = bsearch(lst,k-x)
    if len(lst) > t and x != lst[t] and lst[t] + x == k:
      return True
  return False
