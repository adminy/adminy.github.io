from Node import Node

def add(self, item):
    """ Add this item to its correct position on the tree """
    # This is a non recursive add method.
    if self.root == None: # ... Empty tree ...
        self.root = Node(item, None, None) # ... so, make this the root
    else:
        # Find where to put the item
        parent_stack = [] # Use a list as a stack to hold parents
        child_tree = self.root
        while child_tree != None:
            parent_stack.append(child_tree) # remember the parent for the path back (when checking for AVLness).
            if item < child_tree.item: # If smaller ... 
                child_tree = child_tree.left # ... move to the left
            else:
                child_tree = child_tree.right

        # child_tree is pointing to the new node, but we've gone too far
        # we need to get to the parent to change its pointer
        parent = parent_stack[-1]       # The parent is the last item on the parent stack
        node = Node(item, None, None)
        if item < parent.item: # left?
            parent.left = node
        elif item > parent.item: # right?
            parent.right = node
        else:
            # Else this item is already in the tree and so not added
            return

        # The item has been added, now see if we are AVL unbalanced - go back up the tree.
        while node != None:
            if abs(self.recurse_height(node.left) - self.recurse_height(node.right)) > 1:
                # Found an out of order node! Need to fix
                # First get the three nodes to restructure
                top = node
                mid = top.left if item < top.item else top.right
                bot = mid.left if item < mid.item else mid.right

                # Work out which rotation we need to do. (which one is in the middle)
                if top.item < mid.item < bot.item:
                    # mid in the middle => put on top
                    new_top = mid
                    top.right = mid.left
                    mid.left = top
                elif bot.item < mid.item < top.item:
                    # Right rotation
                    new_top = mid
                    top.left = mid.right
                    mid.right = top
                elif mid.item < bot.item < top.item:
                    # double 1
                    new_top = bot
                    mid.right = bot.left
                    top.left = bot.right
                    bot.left = mid
                    bot.right = top
                else:# top.item < bot.item < mid.item:
                    # double 2
                    new_top = bot
                    mid.left = bot.right
                    top.right = bot.left
                    bot.left = top
                    bot.right = mid
                return top.item

                # Make the parent of top point to the new top
                top_parent = None if len(parent_stack) == 0 else parent_stack.pop()
                if top_parent == None:
                    self.root = new_top
                elif top.item < top_parent.item:
                    top_parent.left = new_top
                else:
                    top_parent.right = new_top
                break

            # Carry on up the path be getting the parent from the stack (which was built on the way down)
            node = None if len(parent_stack) == 0 else parent_stack.pop()
