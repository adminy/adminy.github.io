def is_avl(bst):
    ptr = bst.root
    if ptr and ptr.left and ptr.right:
        return bst.r_height(ptr.left) == bst.r_height(ptr.right)
    else:return False
