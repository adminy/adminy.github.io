def rotation_type(bst):
    node = bst.root
    while node != None:
        if node.left:
            if node.left.left:return "ll"
            elif node.left.right:return "lr"
        elif node.right:
            if node.right.right:return "rr"
            elif node.right.left:return "rl"

