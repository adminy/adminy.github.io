# python3

These are just simple tasks in python3.
